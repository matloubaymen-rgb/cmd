CMD Debate Timer — deploy files
  index.html   -> entire website. All logos (CMD, ENCG, UH1) embedded. Works alone.
  cmd-logo.jpg -> favicon / social share image
  vercel.json  -> static-site config

Deploy: drag the 3 files into vercel.com (Add New -> Project), or push to a
GitHub repo and Import (Framework preset: Other, no build command).

Keyboard: G start/pause Gov · O start/pause Opp · P start/stop POI (running side) · R reset both

Formats & rules:
  Interactive = one shared pool per team (default 12 min, adjustable before start).
    Speakers take turns from the same pool; when it hits 0, no more speakers.
    Reply speech (optional) = whatever pool time the team has LEFT after the last
    speaker, fully protected. Protected time: first & last minute of the pool.
  WSD 4-4-4-2 / 5-5-5-2 / 7-7-7-3 = two side timers. Substantive speeches protect
    first & last minute; reply speeches are fully protected.
  Only one side runs at a time — starting one auto-pauses the other.
  Opening a POI freezes that side's clock until it ends.
